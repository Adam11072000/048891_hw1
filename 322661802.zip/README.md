# 048891_hw1

cd src
pip3 install matplotlib
python3 src/main.py --part <the part u want to run>


